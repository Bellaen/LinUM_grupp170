#ifndef __LIBRESISTANCE__
#define __LIBRESISTANCE__

float calc_resistance(int count, char conn, float *array);

#endif