#include <stdio.h>
#include <stdbool.h>
#include <math.h>

#ifndef __LIBCOMPONENT__
#define __LIBCOMPONENT__

#define E12_LENGTH 12
#define MAX_RESULT 3

int e_resistance(float, float*);
#endif
